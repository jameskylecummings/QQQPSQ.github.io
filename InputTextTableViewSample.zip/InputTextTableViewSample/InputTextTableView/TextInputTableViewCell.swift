//
//  TextInputTableViewCell.swift
//  InputTextTableView
//
//  Created by Tony Diggs on 3/3/18.
//  Copyright © 2018 La Salle Software Inc. All rights reserved.
//

import UIKit

class TextInputTableViewCell: UITableViewCell {
       
 //   @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var textField: UITextField!
    
    
    public func configure(text: String?, placeholder: String) {
        textField.text = text  //Fatal Error
        textField.placeholder = placeholder
        
       textField.accessibilityValue = text
        textField.accessibilityLabel = placeholder
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
