//
//  ViewController.swift
//  InputTextTableView
//
//  Created by Tony Diggs on 3/3/18.
//  Copyright © 2018 La Salle Software Inc. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TextInputCell") as! TextInputTableViewCell
        
        cell.configure(text: "", placeholder: "Enter some text!")
        
        return cell
        
    } // end func
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.tableView.headerViewforSection(1);becomeFirstResponder()
        
       // self.becomeFirstResponder
        
    } // end load    
    
    @IBAction func btnSubmit(_ sender: Any) {
        
  /*
        var StringBuilder: String = ""
  
        let cells = self.tableView.visibleCells as! Array<UITableViewCell>
        
        for cell in cells {
            // look at data
            
            //   print(cell.textLabel?.text)
            
            StringBuilder += (cell.textLabel?.text)! + ","
            
            // print("Value is \(cell.textLabel?.text)!")
            
        } // end for
        
 */
        
 /*
        let cells = self.tableView.visibleCells as! Array<UITableViewCell>
        
 //let cells = self.tableView; indexPathsForVisibleRows
        
//let cells = self.tableView(IndexPath)
 
        for cell in cells {
            
            // look at data let indexPath = IndexPath(row: index, section: 0)
            let indexPath = IndexPath(row: index, section: 0)
            guard let cell = tableView.cellForRow(at: indexPath) as? TextFieldCell
                else{
                       //return nil
                    } 
            if let text = cell.textField.text, !text.isEmpty {
                values[value] = text
                
            } // end if
                
        } // end for
        
 */
        
    /*
        for cell in self.tableView.visibleCell() {
            if let customCell = cell as? TempCell {
                customCell.textField.enabled = false
            }
        }
        
    */
     
  
        let table = UITableView()
        
        for cell in table.visibleCells {
            print(cell) // Crash
            
        } // end for
    
        
    } // end btnSubmit
    
    // Header
     func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        //   return "Section \(section + 1)"
        return "Period Value"
        
    } // end header
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10 // Create 1 row as an example
    }    

} // end class

